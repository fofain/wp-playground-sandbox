<?php
/*
Plugin Name: Demo Pages Creator
Description: Creates demo pages with Elementor content on first admin login.
Version: 1.0
*/

add_action('admin_init', function() {
    // Only run once
    if (get_option('demo_pages_created')) return;

    // Page 1
    $page1_id = wp_insert_post([
        'post_title'    => 'Template 1',
        'post_status'   => 'publish',
        'post_type'     => 'page'
    ]);
    $json1 = file_get_contents('https://raw.githubusercontent.com/fofain/wp-playground-sandbox/main/elementor-4929-2025-10-29.json');
    update_post_meta($page1_id, '_elementor_data', $json1);
    update_post_meta($page1_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page1_id, '_elementor_template_type', 'page');

    // Page 2
    $page2_id = wp_insert_post([
        'post_title'    => 'Template 2',
        'post_status'   => 'publish',
        'post_type'     => 'page'
    ]);
    $json2 = file_get_contents('https://raw.githubusercontent.com/fofain/wp-playground-sandbox/main/elementor-4926-2025-10-29.json');
    update_post_meta($page2_id, '_elementor_data', $json2);
    update_post_meta($page2_id, '_elementor_edit_mode', 'builder');
    update_post_meta($page2_id, '_elementor_template_type', 'page');

    // Run only once
    update_option('demo_pages_created', true);

    // Optional: redirect admin on first login (next page load) to "Template 1"
    if (!isset($_GET['demo-pages-redirected'])) {
        wp_safe_redirect(get_permalink($page1_id) . '?demo-pages-redirected=1');
        exit;
    }
});