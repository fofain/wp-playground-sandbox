<?php
/*
Plugin Name: Demo Pages Creator
Description: Creates demo Elementor templates on first admin login.
Version: 1.2
*/

add_action('admin_init', function() {
    if (get_option('demo_templates_created')) return;

    // Force unique slugs to avoid page conflict
    $template1_id = wp_insert_post([
        'post_title'    => 'Template 1',
        'post_status'   => 'publish',
        'post_type'     => 'elementor_library',
        'post_name'     => 'template-1-' . time()
    ]);
    $json1 = file_get_contents('https://raw.githubusercontent.com/fofain/wp-playground-sandbox/main/elementor-4929-2025-10-29.json');
    update_post_meta($template1_id, '_elementor_data', $json1);
    update_post_meta($template1_id, '_elementor_edit_mode', 'builder');
    update_post_meta($template1_id, '_elementor_template_type', 'page');

    $template2_id = wp_insert_post([
        'post_title'    => 'Template 2',
        'post_status'   => 'publish',
        'post_type'     => 'elementor_library',
        'post_name'     => 'template-2-' . time()
    ]);
    $json2 = file_get_contents('https://raw.githubusercontent.com/fofain/wp-playground-sandbox/main/elementor-4926-2025-10-29.json');
    update_post_meta($template2_id, '_elementor_data', $json2);
    update_post_meta($template2_id, '_elementor_edit_mode', 'builder');
    update_post_meta($template2_id, '_elementor_template_type', 'page');

    update_option('demo_templates_created', true);
});